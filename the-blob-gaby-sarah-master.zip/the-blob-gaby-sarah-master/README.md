# Blob-Data-Lab-Part1
 Starter code for Part 1 of the Blob Data Lab for EESC 4464, Spring 2020

Pre-downloaded data for this lab are provided at https://tinyurl.com/BlobLabOOIdata
These data were originally downloaded from the OOI Data Portal at https://ooinet.oceanobservatories.org/
